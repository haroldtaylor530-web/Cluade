package com.mojang.realmsclient.client;

import java.net.Proxy;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public class RealmsClientConfig {
   @Nullable
   private static Proxy proxy;

   @Nullable
   public static Proxy getProxy() {
      return proxy;
   }

   public static void setProxy(Proxy proxy) {
      if (RealmsClientConfig.proxy == null) {
         RealmsClientConfig.proxy = proxy;
      }
   }
}
