package com.mojang.renderpearl.api.pipeline;

import net.minecraft.resources.Identifier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.shaderc.ShadercIncludeResult;

@OnlyIn(Dist.CLIENT)
public interface ShaderSource extends AutoCloseable {
   @Nullable
   String getShader(Identifier var1, ShaderType var2);

   @Nullable
   ShaderSource.CachedIncludeSource getInclude(Identifier var1);

   @Override
   void close();

   public record CachedIncludeSource(long includeResultPtr) implements AutoCloseable {
      public static ShaderSource.CachedIncludeSource create(Identifier id, String source) {
         ShadercIncludeResult result = ShadercIncludeResult.calloc();
         result.source_name(MemoryUtil.memUTF8(id.toString(), false));
         result.content(MemoryUtil.memUTF8(source, false));
         return new ShaderSource.CachedIncludeSource(result.address());
      }

      public static ShaderSource.CachedIncludeSource createError(String message) {
         ShadercIncludeResult result = ShadercIncludeResult.calloc();
         result.source_name(MemoryUtil.memUTF8("", false));
         result.content(MemoryUtil.memUTF8(message, false));
         return new ShaderSource.CachedIncludeSource(result.address());
      }

      @Override
      public void close() {
         MemoryUtil.nmemFree(MemoryUtil.memGetAddress(this.includeResultPtr + ShadercIncludeResult.SOURCE_NAME));
         MemoryUtil.nmemFree(MemoryUtil.memGetAddress(this.includeResultPtr + ShadercIncludeResult.CONTENT));
         MemoryUtil.nmemFree(this.includeResultPtr);
      }
   }
}
