package com.mojang.renderpearl.api.pipeline;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public enum IndexType {
   SHORT(2),
   INT(4);

   public final int bytes;

   private IndexType(int bytes) {
      this.bytes = bytes;
   }

   public static IndexType least(int length) {
      return (length & -65536) != 0 ? INT : SHORT;
   }
}
