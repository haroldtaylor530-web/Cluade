package com.mojang.renderpearl.frontend.shaders;

import com.mojang.jtracy.TracyClient;
import com.mojang.jtracy.Zone;
import com.mojang.logging.LogUtils;
import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.device.DeviceInfo;
import com.mojang.renderpearl.api.pipeline.BindGroupLayout;
import com.mojang.renderpearl.api.pipeline.CompiledRenderPipeline;
import com.mojang.renderpearl.api.pipeline.PolygonMode;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import com.mojang.renderpearl.api.pipeline.ShaderSource;
import com.mojang.renderpearl.api.pipeline.ShaderType;
import com.mojang.renderpearl.api.pipeline.UniformType;
import com.mojang.renderpearl.api.vertex.VertexFormat;
import com.mojang.renderpearl.api.vertex.VertexFormatElement;
import com.mojang.renderpearl.backend.api.BackendRenderPipeline;
import com.mojang.renderpearl.backend.api.GpuDeviceBackend;
import com.mojang.renderpearl.backend.api.SpvModule;
import com.mojang.renderpearl.frontend.FrontendRenderPipeline;
import com.mojang.renderpearl.util.ShaderCompileException;
import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import it.unimi.dsi.fastutil.objects.Object2IntMaps;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import it.unimi.dsi.fastutil.objects.ReferenceArrayList;
import it.unimi.dsi.fastutil.objects.ReferenceList;
import it.unimi.dsi.fastutil.objects.ReferenceLists;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.resources.Identifier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class PipelineBuilder implements UncheckedAutoCloseable {
   private static final Logger LOGGER = LogUtils.getLogger();
   private final GpuDeviceBackend backendDevice;
   private final GlslCompiler compiler;

   public PipelineBuilder(GpuDeviceBackend backendDevice) {
      this.backendDevice = backendDevice;
      DeviceInfo deviceInfo = backendDevice.getDeviceInfo();
      this.compiler = new GlslCompiler(deviceInfo.isZZeroToOne(), deviceInfo.features().shaderDrawParameters());
   }

   @Override
   public void close() {
      this.compiler.close();
   }

   private BackendRenderPipeline.CreateInfo generateBackendCreateInfo(
      RenderPipeline pipeline,
      ShaderSource shaderSource,
      ReferenceArrayList<BackendRenderPipeline.CreateInfo.Shader> shaderCreateInfos,
      Object2IntOpenHashMap<String> uniformBindings
   ) {
      try {
         EnumMap<ShaderType, SpvModule> shaderSources = new EnumMap<>(ShaderType.class);

         for (Entry<ShaderType, Identifier> shader : pipeline.getShaders().entrySet()) {
            String source = loadShaderSource(shader.getValue(), shader.getKey(), shaderSource);
            if (source == null) {
               LOGGER.error("Couldn't find source for {} shader ({})", shader.getKey(), shader.getValue());
               return null;
            }

            SpvModule spvModule = this.compiler.compileToSpv(shader.getValue().toString(), source, shader.getKey(), pipeline.getShaderDefines(), shaderSource);
            shaderSources.put(shader.getKey(), spvModule);
            shaderCreateInfos.add(new BackendRenderPipeline.CreateInfo.Shader(shader.getValue().toString(), "main", spvModule));
         }

         List<BackendRenderPipeline.CreateInfo.VertexBuffer> vertexBuffers = new ReferenceArrayList();
         List<BackendRenderPipeline.CreateInfo.AttribBinding> attribBindings = new ReferenceArrayList();
         if (shaderSources.containsKey(ShaderType.VERTEX)) {
            Int2ObjectMap<GpuFormat> attribFormats = new Int2ObjectArrayMap();
            SpvModule vertexShader = shaderSources.get(ShaderType.VERTEX);
            List<SpvModule.Reflection.InterfaceVariable> vertexShaderInputs = vertexShader.reflect().inputs();
            String vertexStageName = pipeline.getShaders().get(ShaderType.VERTEX).toString();
            Map<String, SpvModule.Reflection.InterfaceVariable> vertexShaderInputsByName = vertexShaderInputs.stream()
               .collect(Collectors.toUnmodifiableMap(SpvModule.Reflection.InterfaceVariable::name, Function.identity()));
            List<VertexFormat> vertexBindings = pipeline.getVertexFormatBindings();
            String previousElementName = null;
            int previousElementLocation = 0;

            for (int i = 0; i < vertexBindings.size(); i++) {
               VertexFormat vertexBinding = vertexBindings.get(i);
               if (vertexBinding != null) {
                  vertexBuffers.add(new BackendRenderPipeline.CreateInfo.VertexBuffer(i, vertexBinding.getVertexSize(), vertexBinding.getStepRate()));

                  for (VertexFormatElement element : vertexBinding.getElements()) {
                     SpvModule.Reflection.InterfaceVariable input = vertexShaderInputsByName.get(element.name());
                     if (input != null) {
                        int attribLocation;
                        if (element.name().equals(previousElementName)) {
                           attribLocation = previousElementLocation + 1;
                        } else {
                           attribLocation = input.location();
                        }

                        attribBindings.add(new BackendRenderPipeline.CreateInfo.AttribBinding(i, attribLocation, element.offset(), element.format()));
                        attribFormats.put(attribLocation, element.format());
                        previousElementName = element.name();
                        previousElementLocation = attribLocation;
                     }
                  }
               }
            }

            for (SpvModule.Reflection.InterfaceVariable vertexShaderInput : vertexShaderInputs) {
               if (vertexShaderInput.decoration(31) != 0) {
                  throw new ShaderCompileException(
                     String.format(
                        Locale.ROOT,
                        "vertex shader (%s) attrib (%s) has component decoration, this is not permitted",
                        vertexStageName,
                        vertexShaderInput.name()
                     )
                  );
               }

               GpuFormat format = (GpuFormat)attribFormats.get(vertexShaderInput.location());
               if (format == null) {
                  throw new ShaderCompileException(
                     String.format(
                        Locale.ROOT, "vertex shader (%s) attrib (%s) does not have a matching vertex buffer element", vertexStageName, vertexShaderInput.name()
                     )
                  );
               }
               int expectedBaseType = switch (format.componentType()) {
                  case UNORM_8, SNORM_8, UNORM_16, SNORM_16, FLOAT_16, FLOAT_32 -> 13;
                  case UINT_8, UINT_16, UINT_32 -> 8;
                  case SINT_8, SINT_16, SINT_32 -> 7;
                  default -> throw new ShaderCompileException("Unexpected value: " + format.componentType());
               };
               if (expectedBaseType != vertexShaderInput.type().baseType()) {
                  throw new ShaderCompileException(
                     String.format(
                        Locale.ROOT,
                        "Unexpected base type for input attribute %s in vertex shader %s, expected %s got %s",
                        vertexShaderInput.name(),
                        vertexStageName,
                        SpvUtil.baseTypeString(expectedBaseType),
                        SpvUtil.baseTypeString(vertexShaderInput.type().baseType())
                     )
                  );
               }

               if (vertexShaderInput.type().vectorSize() > format.componentCount()) {
                  throw new ShaderCompileException(
                     String.format(
                        Locale.ROOT,
                        "Not enough components for input attribute %s in vertex shader %s, expected at least %s got %s",
                        vertexShaderInput.name(),
                        vertexStageName,
                        vertexShaderInput.type().vectorSize(),
                        format.componentCount()
                     )
                  );
               }
            }
         }

         String vertexStageName;
         Int2ObjectMap<PipelineBuilder.InterfaceVariableInfo> outputSlotMap;
         if (shaderSources.containsKey(ShaderType.VERTEX)) {
            vertexStageName = pipeline.getShaders().get(ShaderType.VERTEX).toString();
            outputSlotMap = generateSlotMap(shaderSources.get(ShaderType.VERTEX).reflect().outputs(), vertexStageName, ShaderType.VERTEX);
         } else {
            vertexStageName = "";
            outputSlotMap = Int2ObjectMaps.emptyMap();
         }

         String fragmentStageName = pipeline.getShaders().get(ShaderType.FRAGMENT).toString();
         Int2ObjectMap<PipelineBuilder.InterfaceVariableInfo> inputSlotMap = generateSlotMap(
            shaderSources.get(ShaderType.FRAGMENT).reflect().inputs(), vertexStageName, ShaderType.FRAGMENT
         );
         ObjectIterator var35 = inputSlotMap.int2ObjectEntrySet().iterator();

         while (var35.hasNext()) {
            it.unimi.dsi.fastutil.ints.Int2ObjectMap.Entry<PipelineBuilder.InterfaceVariableInfo> entry = (it.unimi.dsi.fastutil.ints.Int2ObjectMap.Entry<PipelineBuilder.InterfaceVariableInfo>)var35.next();
            int location = entry.getIntKey();
            PipelineBuilder.InterfaceVariableInfo input = (PipelineBuilder.InterfaceVariableInfo)entry.getValue();

            assert input != null;

            PipelineBuilder.InterfaceVariableInfo output = (PipelineBuilder.InterfaceVariableInfo)outputSlotMap.get(location);
            if (output == null) {
               throw new ShaderCompileException(
                  String.format(
                     Locale.ROOT,
                     "Vertex shader (%s) missing output at location %d consumed by Fragment shader (%s)",
                     vertexStageName,
                     location,
                     fragmentStageName
                  )
               );
            }

            if (!output.equals(input)) {
               if (output.baseType() != input.baseType()) {
                  throw new ShaderCompileException(
                     String.format(
                        Locale.ROOT,
                        "Vertex shader (%s) and Fragment shader (%s) have base type mismatch at location %d of %s and %s.",
                        vertexStageName,
                        fragmentStageName,
                        location,
                        SpvUtil.baseTypeString(output.baseType()),
                        SpvUtil.baseTypeString(input.baseType())
                     )
                  );
               }

               if (output.vectorLength() != input.vectorLength()) {
                  throw new ShaderCompileException(
                     String.format(
                        Locale.ROOT,
                        "Vertex shader (%s) and Fragment shader (%s) have vector length mismatch at location %d of %d and %d.",
                        vertexStageName,
                        fragmentStageName,
                        location,
                        output.vectorLength(),
                        input.vectorLength()
                     )
                  );
               }

               if (output.flatInterpolated() != input.flatInterpolated()) {
                  throw new ShaderCompileException(
                     String.format(
                        Locale.ROOT,
                        "Vertex shader (%s) and Fragment shader (%s) have mismatched interpolation at location %d, flat in %s",
                        vertexStageName,
                        fragmentStageName,
                        location,
                        output.flatInterpolated() ? "vertex" : "fragment"
                     )
                  );
               }
            }
         }

         List<BindGroupLayout.UniformDescription> pipelineUniforms = BindGroupLayout.flattenUniforms(pipeline.getBindGroupLayouts());
         Map<String, BindGroupLayout.UniformDescription> pipelineUniformsByName = new Object2ObjectOpenHashMap();

         for (BindGroupLayout.UniformDescription pipelineUniform : pipelineUniforms) {
            pipelineUniformsByName.put(pipelineUniform.name(), pipelineUniform);
         }

         IntList uniformResourceTypes = new IntArrayList();
         IntList uniformDimensions = new IntArrayList();
         ReferenceList<BindGroupLayout.UniformDescription> uniforms = new ReferenceArrayList();
         ObjectListIterator var49 = shaderCreateInfos.iterator();

         while (var49.hasNext()) {
            BackendRenderPipeline.CreateInfo.Shader shader = (BackendRenderPipeline.CreateInfo.Shader)var49.next();
            SpvModule.Reflection reflectionInfo = shader.module().reflect();

            for (SpvModule.Reflection.Descriptor descriptor : reflectionInfo.descriptors()) {
               String uniformName = descriptor.name();
               SpvModule.Reflection.Type type = descriptor.type();
               BindGroupLayout.UniformDescription pipelineUniform = pipelineUniformsByName.get(uniformName);
               if (pipelineUniform == null) {
                  throw new ShaderCompileException("Unable to find shader defined uniform (" + uniformName + ")");
               }

               int newBinding = uniformBindings.computeIfAbsent(descriptor.name(), var1x -> uniformBindings.size());
               if (newBinding >= uniformResourceTypes.size()) {
                  uniformResourceTypes.add(descriptor.resourceType());
                  uniformDimensions.add(type.dimensions());
                  uniforms.add(new BindGroupLayout.UniformDescription(pipelineUniform.name(), pipelineUniform.type(), pipelineUniform.gpuFormat()));
               } else {
                  if (descriptor.resourceType() != uniformResourceTypes.getInt(newBinding)) {
                     throw new ShaderCompileException("Uniform type for " + descriptor.name() + " does not match across all stages");
                  }

                  if (type.dimensions() != uniformDimensions.getInt(newBinding)) {
                     throw new ShaderCompileException("Uniform dimensions for " + descriptor.name() + " does not match across all stages");
                  }
               }

               descriptor.binding(newBinding);
               descriptor.descriptorSetIndex(0);
            }
         }

         ObjectIterator var50 = uniformBindings.keySet().iterator();

         while (var50.hasNext()) {
            String uniformNamex = (String)var50.next();
            BindGroupLayout.UniformDescription pipelineUniformx = pipelineUniformsByName.get(uniformNamex);

            assert pipelineUniformx != null;

            int uniformBinding = uniformBindings.getInt(uniformNamex);
            int definedResourceType = uniformResourceTypes.getInt(uniformBinding);
            int expectedResourceType = SpvUtil.resourceType(pipelineUniformx.type());
            int definedDimensions = uniformDimensions.getInt(uniformBinding);
            if (expectedResourceType != definedResourceType) {
               throw new ShaderCompileException("Uniform type in shader does not match expected type from RenderPipeline for (" + uniformNamex + ")");
            }

            if (definedDimensions != Integer.MAX_VALUE) {
               UniformType expectedUniformType = switch (definedDimensions) {
                  case 0 -> throw new ShaderCompileException("1D textures not supported (" + uniformNamex + ")");
                  case 1 -> UniformType.COMBINED_IMAGE_SAMPLER;
                  case 2 -> throw new ShaderCompileException("3D textures not supported (" + uniformNamex + ")");
                  case 3 -> UniformType.COMBINED_IMAGE_SAMPLER;
                  case 4 -> UniformType.COMBINED_IMAGE_SAMPLER;
                  case 5 -> UniformType.TEXEL_BUFFER;
                  default -> throw new ShaderCompileException("Unexpected SpvDim (" + definedDimensions + ") for uniform (" + uniformNamex + ")");
               };
               if (pipelineUniformx.type() != expectedUniformType) {
                  throw new ShaderCompileException("Unexpected dimensions for uniform (" + uniformNamex + "), does not match RenderPipeline definition");
               }
            }
         }

         var49 = shaderCreateInfos.iterator();

         while (var49.hasNext()) {
            BackendRenderPipeline.CreateInfo.Shader shader = (BackendRenderPipeline.CreateInfo.Shader)var49.next();
            List<SpvModule.Reflection.PushConstant> pushConstants = shader.module().reflect().pushConstants();
            if (!pushConstants.isEmpty()) {
               if (pushConstants.size() > 1) {
                  throw new ShaderCompileException("Shader may define at most one push_constant block");
               }

               SpvModule.Reflection.PushConstant pushConstant = pushConstants.getFirst();
               if (pushConstant.size() > pipeline.pushConstantSize()) {
                  throw new ShaderCompileException("Shader push constant size exceeds pipeline declared size");
               }
            }
         }

         return new BackendRenderPipeline.CreateInfo(
            pipeline.getLocation().toString(),
            List.copyOf(shaderCreateInfos),
            List.copyOf(vertexBuffers),
            List.copyOf(attribBindings),
            List.copyOf(uniforms),
            pipeline.pushConstantSize(),
            pipeline.getDepthStencilState(),
            pipeline.getPolygonMode(),
            pipeline.isCull(),
            pipeline.getColorTargetStates(),
            pipeline.getPrimitiveTopology()
         );
      } catch (ShaderCompileException var26) {
         LOGGER.error("Couldn't compile pipeline ({}): ", pipeline.getLocation(), var26);
         shaderCreateInfos.forEach(shader -> shader.module().close());
         return null;
      }
   }

   public CompletableFuture<CompiledRenderPipeline.Pending> compilePipeline(RenderPipeline pipeline, ShaderSource shaderSource, Executor executor) {
      if (pipeline.getPolygonMode() == PolygonMode.WIREFRAME && !this.backendDevice.getDeviceInfo().features().wireframeFillMode()) {
         LOGGER.error("Pipeline {} uses {} fill mode, not supported by device", pipeline.getLocation(), PolygonMode.WIREFRAME);
         return CompletableFuture.completedFuture(CompiledRenderPipeline.Pending.NULL);
      } else {
         return CompletableFuture.supplyAsync(
            () -> {
               ReferenceArrayList<BackendRenderPipeline.CreateInfo.Shader> shaderCreateInfos = new ReferenceArrayList();
               Object2IntOpenHashMap<String> uniformBindings = new Object2IntOpenHashMap();
               Zone tracyZone = TracyClient.beginZone("Frontend Compile and reflection", false);

               BackendRenderPipeline.CreateInfo createInfo;
               try {
                  tracyZone.addText(pipeline.getLocation().toString());
                  createInfo = this.generateBackendCreateInfo(pipeline, shaderSource, shaderCreateInfos, uniformBindings);
               } catch (Throwable var14) {
                  if (tracyZone != null) {
                     try {
                        tracyZone.close();
                     } catch (Throwable var12) {
                        var14.addSuppressed(var12);
                     }
                  }

                  throw var14;
               }

               if (tracyZone != null) {
                  tracyZone.close();
               }

               if (createInfo == null) {
                  return CompiledRenderPipeline.Pending.NULL;
               } else {
                  Zone tracyZonex = TracyClient.beginZone("Backend Compile", false);

                  try {
                     tracyZonex.addText(pipeline.getLocation().toString());
                     backendPendingPipeline = this.backendDevice.compilePipeline(createInfo);
                  } catch (Throwable var13) {
                     if (tracyZonex != null) {
                        try {
                           tracyZonex.close();
                        } catch (Throwable var11) {
                           var13.addSuppressed(var11);
                        }
                     }

                     throw var13;
                  }

                  if (tracyZonex != null) {
                     tracyZonex.close();
                  }

                  return () -> {
                     Zone tracyZonexx = TracyClient.beginZone("Complete Compile", false);

                     BackendRenderPipeline backendPipeline;
                     try {
                        tracyZonexx.addText(pipeline.getLocation().toString());
                        backendPipeline = backendPendingPipeline.finishCompile();
                     } catch (Throwable var10) {
                        if (tracyZonexx != null) {
                           try {
                              tracyZonexx.close();
                           } catch (Throwable var9) {
                              var10.addSuppressed(var9);
                           }
                        }

                        throw var10;
                     }

                     if (tracyZonexx != null) {
                        tracyZonexx.close();
                     }

                     executor.execute(() -> shaderCreateInfos.forEach(shader -> shader.module().close()));
                     return backendPipeline == null
                        ? null
                        : new FrontendRenderPipeline(
                           pipeline.getLocation().toString(),
                           backendPipeline,
                           ReferenceLists.unmodifiable(new ReferenceArrayList(pipeline.getVertexFormatBindings())),
                           Object2IntMaps.unmodifiable(uniformBindings),
                           BindGroupLayout.flattenUniforms(pipeline.getBindGroupLayouts()),
                           ReferenceLists.unmodifiable(new ReferenceArrayList(pipeline.getColorTargetStates())),
                           pipeline.wantsDepthTexture(),
                           pipeline.pushConstantSize()
                        );
                  };
               }
            },
            executor
         );
      }
   }

   @Nullable
   private static String loadShaderSource(Identifier id, ShaderType type, ShaderSource shaderSource) {
      String source = shaderSource.getShader(id, type);
      if (source == null) {
         LOGGER.error("Couldn't find source for {} shader ({})", type, id);
         return null;
      } else {
         return source;
      }
   }

   private static Int2ObjectMap<PipelineBuilder.InterfaceVariableInfo> generateSlotMap(
      List<SpvModule.Reflection.InterfaceVariable> interfaceVariables, String stageName, ShaderType shaderType
   ) throws ShaderCompileException {
      Int2ObjectMap<PipelineBuilder.InterfaceVariableInfo> slotMap = new Int2ObjectArrayMap();

      for (SpvModule.Reflection.InterfaceVariable interfaceVariable : interfaceVariables) {
         SpvModule.Reflection.Type interfaceVariableType = interfaceVariable.type();
         int baseLocation = interfaceVariable.location();
         if (interfaceVariable.decoration(31) != 0) {
            throw new ShaderCompileException(
               String.format(
                  Locale.ROOT,
                  "%s shader (%s) interface (%s) has component decoration, this is not permitted",
                  shaderType.getName(),
                  stageName,
                  interfaceVariable.name()
               )
            );
         }

         switch (interfaceVariableType.baseType()) {
            case 9:
            case 10:
            case 14:
            case 15:
               throw new ShaderCompileException(
                  String.format(
                     Locale.ROOT,
                     "Unsupported interface variable type %s in %s shader (%s) location %d",
                     SpvUtil.baseTypeString(interfaceVariableType.baseType()),
                     shaderType.getName(),
                     stageName,
                     baseLocation
                  )
               );
            case 11:
            case 12:
            case 13:
         }

         PipelineBuilder.InterfaceVariableInfo info = new PipelineBuilder.InterfaceVariableInfo(
            interfaceVariableType.baseType(), interfaceVariableType.vectorSize(), interfaceVariable.hasDecoration(14)
         );
         int totalArraySize = 1;
         int arrayDimensions = interfaceVariableType.arrayDimensions();
         if (arrayDimensions > 0) {
            for (int i = 0; i < arrayDimensions; i++) {
               totalArraySize *= interfaceVariableType.arrayLength(i);
            }
         }

         for (int i = 0; i < totalArraySize; i++) {
            slotMap.put(baseLocation + i, info);
         }
      }

      return slotMap;
   }

   private record InterfaceVariableInfo(int baseType, int vectorLength, boolean flatInterpolated) {
   }
}
