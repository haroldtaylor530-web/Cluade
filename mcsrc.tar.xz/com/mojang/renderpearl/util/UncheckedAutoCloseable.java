package com.mojang.renderpearl.util;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public interface UncheckedAutoCloseable extends AutoCloseable {
   @Override
   void close();

   static void safeClose(@Nullable UncheckedAutoCloseable closeable) {
      if (closeable != null) {
         closeable.close();
      }
   }
}
