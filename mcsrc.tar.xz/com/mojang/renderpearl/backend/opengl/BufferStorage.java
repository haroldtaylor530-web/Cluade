package com.mojang.renderpearl.backend.opengl;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import java.nio.ByteBuffer;
import java.util.Set;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.lwjgl.opengl.GLCapabilities;

@OnlyIn(Dist.CLIENT)
public abstract class BufferStorage {
   public static BufferStorage create(GLCapabilities capabilities, Set<String> enabledExtensions, boolean forceMutable) {
      if (!forceMutable && capabilities.GL_ARB_buffer_storage && GlDevice.USE_GL_ARB_buffer_storage) {
         enabledExtensions.add("GL_ARB_buffer_storage");
         return new BufferStorage.Immutable();
      } else {
         return new BufferStorage.Mutable();
      }
   }

   public abstract GlBuffer createBuffer(GlHeuristics var1, DirectStateAccess var2, @GpuBuffer.Usage int var3, long var4);

   public abstract GlBuffer createBuffer(GlHeuristics var1, DirectStateAccess var2, @GpuBuffer.Usage int var3, ByteBuffer var4);

   private static class Immutable extends BufferStorage {
      @Override
      public GlBuffer createBuffer(GlHeuristics heuristics, DirectStateAccess dsa, @GpuBuffer.Usage int usage, long size) {
         int buffer = dsa.createBuffer();
         dsa.bufferStorage(buffer, size, usage);
         return new GlBuffer.Direct(heuristics, dsa, usage, size, buffer, true);
      }

      @Override
      public GlBuffer createBuffer(GlHeuristics heuristics, DirectStateAccess dsa, @GpuBuffer.Usage int usage, ByteBuffer data) {
         int buffer = dsa.createBuffer();
         int size = data.remaining();
         dsa.bufferStorage(buffer, data, usage);
         return new GlBuffer.Direct(heuristics, dsa, usage, size, buffer, true);
      }
   }

   private static class Mutable extends BufferStorage {
      @Override
      public GlBuffer createBuffer(GlHeuristics heuristics, DirectStateAccess dsa, @GpuBuffer.Usage int usage, long size) {
         int buffer = dsa.createBuffer();
         dsa.bufferData(buffer, size, usage);
         return new GlBuffer.Direct(heuristics, dsa, usage, size, buffer, false);
      }

      @Override
      public GlBuffer createBuffer(GlHeuristics heuristics, DirectStateAccess dsa, @GpuBuffer.Usage int usage, ByteBuffer data) {
         int buffer = dsa.createBuffer();
         int size = data.remaining();
         dsa.bufferData(buffer, data, usage);
         return new GlBuffer.Direct(heuristics, dsa, usage, size, buffer, false);
      }
   }
}
