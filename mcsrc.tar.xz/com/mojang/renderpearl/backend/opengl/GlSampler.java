package com.mojang.renderpearl.backend.opengl;

import com.mojang.renderpearl.api.textures.AddressMode;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuSampler;
import java.util.OptionalDouble;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.lwjgl.opengl.GL33C;

@OnlyIn(Dist.CLIENT)
public class GlSampler implements GpuSampler {
   private final int id;
   private final AddressMode addressModeU;
   private final AddressMode addressModeV;
   private final FilterMode minFilter;
   private final FilterMode magFilter;
   private final int maxAnisotropy;
   private final OptionalDouble maxLod;
   private boolean closed;

   public GlSampler(AddressMode addressModeU, AddressMode addressModeV, FilterMode minFilter, FilterMode magFilter, int maxAnisotropy, OptionalDouble maxLod) {
      this.addressModeU = addressModeU;
      this.addressModeV = addressModeV;
      this.minFilter = minFilter;
      this.magFilter = magFilter;
      this.maxAnisotropy = maxAnisotropy;
      this.maxLod = maxLod;
      this.id = GL33C.glGenSamplers();
      GL33C.glSamplerParameteri(this.id, 10242, GlConst.toGl(addressModeU));
      GL33C.glSamplerParameteri(this.id, 10243, GlConst.toGl(addressModeV));
      if (maxAnisotropy > 1) {
         GL33C.glSamplerParameterf(this.id, 34046, maxAnisotropy);
      }

      switch (minFilter) {
         case NEAREST:
            GL33C.glSamplerParameteri(this.id, 10241, 9986);
            break;
         case LINEAR:
            GL33C.glSamplerParameteri(this.id, 10241, 9987);
      }

      switch (magFilter) {
         case NEAREST:
            GL33C.glSamplerParameteri(this.id, 10240, 9728);
            break;
         case LINEAR:
            GL33C.glSamplerParameteri(this.id, 10240, 9729);
      }

      if (maxLod.isPresent()) {
         GL33C.glSamplerParameterf(this.id, 33083, (float)maxLod.getAsDouble());
      }
   }

   public int getId() {
      return this.id;
   }

   @Override
   public AddressMode getAddressModeU() {
      return this.addressModeU;
   }

   @Override
   public AddressMode getAddressModeV() {
      return this.addressModeV;
   }

   @Override
   public FilterMode getMinFilter() {
      return this.minFilter;
   }

   @Override
   public FilterMode getMagFilter() {
      return this.magFilter;
   }

   @Override
   public int getMaxAnisotropy() {
      return this.maxAnisotropy;
   }

   @Override
   public OptionalDouble getMaxLod() {
      return this.maxLod;
   }

   @Override
   public void close() {
      if (!this.closed) {
         this.closed = true;
         GL33C.glDeleteSamplers(this.id);
      }
   }

   @Override
   public boolean isClosed() {
      return this.closed;
   }
}
